#!/usr/bin/env python3
# fanmon.py - 风扇状态滚动监控 + 动态 sparkline 曲线
# 不清除屏幕，保留完整历史记录；每行带最近 N 个采样点的迷你曲线
import subprocess, re, time, sys

SPARK = "▁▂▃▄▅▆▇█"   # 8 级高度
WIDTH = 50            # 曲线保留的采样点数

def spark(hist, lo, hi):
    if not hist:
        return ""
    span = max(hi - lo, 1)
    return "".join(SPARK[min(len(SPARK) - 1, (v - lo) * len(SPARK) // span)] for v in hist)

def main():
    thist, phist, rhist = [], [], []
    print("时间      CPU    PWM   RPM   温度曲线                        占空比曲线")
    print("-" * 78)
    try:
        while True:
            try:
                out = subprocess.check_output(
                    ["python3", "/volume1/scripts/fanctl.py", "status"],
                    stderr=subprocess.DEVNULL).decode()
            except Exception:
                out = ""
            m = re.search(r"CPU=(\d+)C\s+PWM=(\d+)%\s+RPM=(\d+|\S+)", out)
            if m:
                t = int(m.group(1))
                p = int(m.group(2))
                r = m.group(3)
                thist.append(t); phist.append(p)
                thist = thist[-WIDTH:]; phist = phist[-WIDTH:]
                ts = time.strftime("%H:%M:%S")
                print(f"{ts}  {t:>3}C  {p:>3}%  {r:>4}  T[{spark(thist,30,90)}]  P[{spark(phist,0,100)}]")
                sys.stdout.flush()
            time.sleep(2)
    except KeyboardInterrupt:
        print("\n(已停止)")

if __name__ == "__main__":
    main()
