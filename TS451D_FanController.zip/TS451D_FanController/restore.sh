#!/bin/bash
# TS-451D 风扇控制 — 一键部署脚本
# 在 NAS 上 root SSH 执行

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG=/var/log/fanctl.log

echo "=== TS-451D Fan Controller 部署 ==="

# 1. 创建目录
echo "[1/5] 创建目录..."
mkdir -p /volume1/scripts
mkdir -p /usr/local/etc/rc.d

# 2. 复制文件
echo "[2/5] 复制文件..."
cp "$SCRIPT_DIR/fanctl.py" /volume1/scripts/fanctl.py
cp "$SCRIPT_DIR/S99fanctl.sh" /usr/local/etc/rc.d/S99fanctl.sh
chmod +x /volume1/scripts/fanctl.py
chmod +x /usr/local/etc/rc.d/S99fanctl.sh
echo "  fanctl.py -> /volume1/scripts/"
echo "  S99fanctl.sh -> /usr/local/etc/rc.d/"

# 3. 验证
echo "[3/5] 验证 EC 端口..."
CMD_VAL=$(python3 -c "import struct; f=open('/dev/port','rb'); f.seek(0x6c); print(hex(struct.unpack('B',f.read(1))[0]))")
DAT_VAL=$(python3 -c "import struct; f=open('/dev/port','rb'); f.seek(0x68); print(hex(struct.unpack('B',f.read(1))[0]))")
echo "  CMD 0x6c = $CMD_VAL"
echo "  DAT 0x68 = $DAT_VAL"
if [ "$CMD_VAL" = "0x0" ] && [ "$DAT_VAL" = "0x0" ]; then
    echo "  ⚠️  CMD/DAT 全 0，EC 可能不响应，跳过启动"
else
    echo "  ✅ EC 端口正常"
fi

# 4. 测试设置
echo "[4/5] 测试手动控制..."
python3 /volume1/scripts/fanctl.py set 50
sleep 1
python3 /volume1/scripts/fanctl.py set 90
echo "  ✅ 手动设置 OK"

# 5. 启动守护进程
echo "[5/5] 启动守护进程..."
# 先杀掉旧的
pkill -f "fanctl.py control" 2>/dev/null || true
sleep 1

nohup python3 /volume1/scripts/fanctl.py control >> $LOG 2>&1 &
PID=$!
echo "  PID=$PID"

sleep 5
echo ""
echo "=== 部署完成 ==="
echo "守护进程 PID: $PID"
echo "日志: $LOG"
echo ""
python3 /volume1/scripts/fanctl.py status
echo ""
echo "查看日志: tail -f $LOG"
echo "重启守护: /usr/local/etc/rc.d/S99fanctl.sh restart"
