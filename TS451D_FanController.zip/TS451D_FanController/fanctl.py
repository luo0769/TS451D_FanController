#!/usr/bin/env python3
"""TS-451D 风扇控制 - 用户态直控 IT8528 EC

通过 /dev/port 直接读写 Embedded Controller 寄存器控制风扇 PWM，
纯用户态实现，不加载任何内核模块。

  EC 命令/数据端口 : CMD=0x6c, DAT=0x68
  风扇通道 Fan0-5   : ctrl=0x220 (手动模式位), pwm=0x22e (占空比 0-100)
  温度来源          : coretemp hwmon (优先) / EC 0x0005 (兜底)
"""
import struct, time, sys, signal, os

CMD, DAT = 0x6c, 0x68

def port_read(p):
    with open("/dev/port", "rb") as f:
        f.seek(p)
        return struct.unpack("B", f.read(1))[0]

def port_write(p, v):
    with open("/dev/port", "rb+") as f:
        f.seek(p)
        f.write(struct.pack("B", v & 0xFF))

def wait_ibf(timeout_ms=100):
    for _ in range(timeout_ms):
        if not (port_read(CMD) & 2): return 0
        time.sleep(0.001)
    return -1

def wait_obf(timeout_ms=100):
    for _ in range(timeout_ms):
        if port_read(CMD) & 1: return 0
        time.sleep(0.001)
    return -1

def ec_clear():
    for _ in range(50):
        if not (port_read(CMD) & 1): break
        port_read(DAT)
        time.sleep(0.001)

def ec_send(cmd):
    ec_clear()
    if wait_ibf() < 0: return -1
    port_write(CMD, 0x88)
    if wait_ibf() < 0: return -1
    port_write(DAT, (cmd >> 8) & 0xFF)
    if wait_ibf() < 0: return -1
    port_write(DAT, cmd & 0xFF)
    return 0

def ec_read(cmd, retries=3):
    """读取 EC 寄存器字节（命令+握手协议）。"""
    for _ in range(retries):
        if ec_send(cmd) < 0: time.sleep(0.005); continue
        if wait_obf() < 0: time.sleep(0.005); continue
        return port_read(DAT)
    return None

def ec_write(cmd, val, retries=3):
    """写入 EC 寄存器字节（命令+握手协议）。"""
    cmd_w = cmd | 0x8000
    for _ in range(retries):
        if ec_send(cmd_w) < 0: time.sleep(0.005); continue
        if wait_ibf() < 0: time.sleep(0.005); continue
        port_write(DAT, val & 0xFF)
        time.sleep(0.005)
        return 0
    return None

# --- 风扇 PWM 控制（Fan0-5: ctrl=0x220, pwm=0x22e）---
FAN_CTRL_REG = 0x220
FAN_PWM_REG  = 0x22e

def set_pwm_duty(duty):
    """设置风扇占空比 0-100%。"""
    duty = max(0, min(100, int(duty)))
    ec_write(FAN_CTRL_REG, 0x10)  # 开启手动模式
    time.sleep(0.002)
    ec_write(FAN_PWM_REG, duty)
    time.sleep(0.005)
    return duty

def get_pwm_duty():
    """读取当前占空比 (0-100)。"""
    v = ec_read(FAN_PWM_REG)
    return v if v is not None and 0 <= v <= 100 else None

# --- 温度来源：coretemp hwmon (优先) / EC 0x0005 (兜底) ---
def get_temp():
    """读取 CPU 封装温度（摄氏度）。"""
    try:
        for name in os.listdir("/sys/class/hwmon"):
            path = f"/sys/class/hwmon/{name}"
            try:
                with open(f"{path}/name") as f:
                    if f.read().strip() == "coretemp":
                        with open(f"{path}/temp1_input") as f:
                            return int(f.read().strip()) // 1000
            except (IOError, OSError, ValueError):
                pass
    except (IOError, OSError):
        pass
    t = ec_read(0x0005)
    if t is not None and 20 <= t <= 110:
        return t
    return None

def get_rpm_raw():
    """读取风扇 RPM（EC 命令 0x0101，无测速线时返回 0 属正常）。"""
    return ec_read(0x0101)

# --- 温度→占空比曲线 ---
def temp_to_duty(temp):
    if temp < 45:   return 30
    elif temp < 55: return 45
    elif temp < 65: return 60
    elif temp < 75: return 75
    elif temp < 85: return 90
    else:           return 100

# --- 配置 ---
INTERVAL = 10
LOGFILE  = "/var/log/fanctl.log"
PIDFILE  = "/var/run/fanctl.pid"

_last_temp = None

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOGFILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass

def signal_handler(signum, frame):
    log("Received signal, shutting down...")
    sys.exit(0)

def fmt_temp(t):
    return f"{t}C" if t is not None else "N/A"

def fmt_pwm(d):
    return f"{d}%" if d is not None else "N/A"

if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "status"

    if action == "status":
        t   = get_temp()
        d   = get_pwm_duty()
        rpm = get_rpm_raw()
        log(f"CPU={fmt_temp(t)}  PWM={fmt_pwm(d)}  RPM={rpm}")

    elif action == "set":
        duty = int(sys.argv[2])
        set_pwm_duty(duty)
        time.sleep(0.5)
        d = get_pwm_duty()
        log(f"Set PWM={fmt_pwm(d)}")

    elif action == "control":
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT,  signal_handler)
        log("Fan controller started (interval=10s)")
        log("Curve: <45C=30% | 45-55=45% | 55-65=60% | 65-75=75% | 75-85=90% | >=85=100%")
        try:
            while True:
                t = get_temp()
                if t is None:
                    last_str = fmt_temp(_last_temp)
                    log(f"Warning: temp read failed, last={last_str}")
                    time.sleep(INTERVAL)
                    continue
                _last_temp = t
                duty = temp_to_duty(t)
                set_pwm_duty(duty)
                time.sleep(0.5)
                d   = get_pwm_duty()
                rpm = get_rpm_raw()
                log(f"CPU={fmt_temp(t)} -> PWM={fmt_pwm(d)} (target={duty}%) RPM={rpm}")
                time.sleep(INTERVAL)
        except KeyboardInterrupt:
            log("Stopped")
        except Exception as e:
            log(f"Error: {e}")
