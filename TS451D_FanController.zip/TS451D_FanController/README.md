# TS-451D 黑群晖风扇控制器 — 使用文档

## 1. 适用与现状
- **机器**：威联通 TS-451D（Intel Celeron J4025，4Pin PWM 风扇）
- **系统**：RR 引导 + 黑群晖 DSM（当前机型 DS918+，所有功能正常）
- **控制方案**：用户态 Python 直控主板 IT8528 EC（通过 `/dev/port` 读写端口 `0x6c`/`0x68`），**纯用户态，不加载任何内核模块**
- **已验证**：温度联动调速、手动调速、开机自启、CodecPack 转码激活均正常

## 2. 文件清单
| 文件 | 作用 | 部署位置 |
|------|------|----------|
| `fanctl.py` | 风扇控制主程序（status / set / control 三种模式） | `/volume1/scripts/fanctl.py` |
| `fanmon.py` | 动态曲线监控（持续显示温度/PWM 趋势） | `/volume1/scripts/fanmon.py`（可选） |
| `S99fanctl.sh` | 开机自启脚本 | `/usr/local/etc/rc.d/S99fanctl.sh` |
| `restore.sh` | 一键部署（重装后运行） | 随包上传，NAS 上执行 |
| `package/` | 上述文件打包目录 | — |

## 3. 安装 / 部署命令
> 重装系统或迁移后执行。黑群晖默认 scp 不可用，推荐用 DSM 文件管理器或 SSH base64 管道上传。

**方式 A：DSM 文件管理器（Web）**
1. 把 `package/` 整个目录上传到 NAS（如 `/volume1/backup/ts451d_fanctl/`）
2. SSH 进 NAS（控制面板 → 终端机和 SNMP → 启用 SSH），运行：
   ```bash
   bash /volume1/backup/ts451d_fanctl/restore.sh
   ```

**方式 B：SSH base64 管道（Mac 侧，需开 SSH）**
```bash
# 上传 fanctl.py
B64=$(base64 -i fanctl.py)
ssh root@<NAS_IP> "mkdir -p /volume1/scripts && echo '$B64' | base64 -d > /volume1/scripts/fanctl.py"
# 上传 S99fanctl.sh
B64=$(base64 -i S99fanctl.sh)
ssh root@<NAS_IP> "echo '$B64' | base64 -d > /usr/local/etc/rc.d/S99fanctl.sh && chmod +x /usr/local/etc/rc.d/S99fanctl.sh"
# 上传并运行一键部署
B64=$(base64 -i restore.sh)
ssh root@<NAS_IP> "echo '$B64' | base64 -d > /volume1/backup/restore.sh && bash /volume1/backup/restore.sh"
```

**方式 C：已上传包后一键部署**
```bash
bash /volume1/backup/ts451d_fanctl/restore.sh
```

## 4. 查看命令
```bash
# 当前状态（温度 / PWM / RPM）
python3 /volume1/scripts/fanctl.py status

# 手动调速（0-100）
python3 /volume1/scripts/fanctl.py set 100   # 全速
python3 /volume1/scripts/fanctl.py set 30    # 低速

# 实时日志（守护进程每 10 秒记一条）
tail -f /var/log/fanctl.log

# 重启守护 / 触发开机自启
/usr/local/etc/rc.d/S99fanctl.sh restart
```

## 5. 持续查看温度与风扇状态（动态）
```bash
# 推荐：动态 sparkline 曲线（不清屏，历史全保留）
python3 /volume1/scripts/fanmon.py

# 或：纯滚动输出（无曲线，保留全部记录）
while true; do python3 /volume1/scripts/fanctl.py status; sleep 2; done
```
`fanmon.py` 输出示例：
```
时间      CPU   PWM   RPM   温度曲线                        占空比曲线
16:35:01  45C   30%   24   T[▁▁▁▁▂▂▃▄▅▆]  P[▁▁▁▁▁▁▁▁▁▁]
16:35:03  52C   45%   24   T[▁▁▁▂▂▃▃▄▅▆▇]  P[▁▁▁▁▁▁▂▂▂▃]
```

## 6. 温控曲线
| CPU 温度 | PWM 占空比 |
|---------|-----------|
| < 45°C  | 30% |
| 45–55°C | 45% |
| 55–65°C | 60% |
| 65–75°C | 75% |
| 75–85°C | 90% |
| ≥ 85°C  | 100% |

## 7. 已知问题与解决
- **内核模块方案不适用**：TS-451D 的主板 EC 不受标准内核风扇驱动支持，在黑群晖上也缺少内核头文件、无法编译第三方驱动。最终采用用户态 EC 直控方案，**完全不需要内核模块**（相关内核模块编译文件已移除）。

## 8. 备注
- 部分机型重启会清空 `/volume1/scripts` 和 `/usr/local/etc/rc.d/`（取决于持久化策略）。重装或异常重启后，重新运行 `restore.sh` 即可恢复。
- 无风扇测速线时 RPM 显示 `0` / `N/A` 属正常，不影响调速。
- 温度优先读 `coretemp` hwmon，失败才回退 EC 命令，与机型无关。
