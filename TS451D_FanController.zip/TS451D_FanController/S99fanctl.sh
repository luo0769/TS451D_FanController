#!/bin/bash
# TS-451D Fan Controller - Synology startup script
# Place in /usr/local/etc/rc.d/S99fanctl.sh (executable)

NAME=fanctl
SCRIPT=/volume1/scripts/fanctl.py
PIDFILE=/var/run/fanctl.pid
LOG=/var/log/fanctl.log

start() {
    echo "Starting $NAME..."
    python3 $SCRIPT control 10 >> $LOG 2>&1 &
    echo $! > $PIDFILE
    echo "$NAME started (PID=$(cat $PIDFILE))"
}

stop() {
    if [ -f $PIDFILE ]; then
        kill $(cat $PIDFILE) 2>/dev/null
        rm -f $PIDFILE
        echo "$NAME stopped"
    fi
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        sleep 2
        start
        ;;
    *)
        echo "Usage: $0 {start|stop|restart}"
        exit 1
        ;;
esac
